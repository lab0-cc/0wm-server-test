let mW dBm = 10. ** (dBm /. 10.)

let dBm mW = 10. *. log10 mW
